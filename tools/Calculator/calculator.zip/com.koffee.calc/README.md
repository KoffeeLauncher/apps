# JS-Calculator
A calculator web app made using HTML,CSS and JavaScript.

# Features :-

 - I can add,multiply,subtract and divide and modulo operations on two numbers on it.
 - I can chain numbers and operators together until I click '=' and get result on a screen.
 - I can clear input field using a CE button.
 - I can restart my calculator using AC button.
 - It saves previous result and you can access it using ANS button.
 - Handles Divide by Zero Error. 
 - Handles Negative Numbers.

# Things learnt :-

 - Callback function on click events.
 - Converting Infix Expression to Postfix and then evaluating postfix expression on multidigit numbers.
 
# To-Do :-
 
 - Parentheses Support.
